var container = document.getElementById('popup');
var content = document.getElementById('popup-content');
var closer = document.getElementById('popup-closer');
closer.onclick = function() {
    container.style.display = 'none';
    closer.blur();
    return false;
};

var overlayPopup = new ol.Overlay({
    element: container
});

var view = new ol.View({
    center: [0, 0],
    zoom: 7,
    maxZoom: 32,
    minZoom: 1,
    projection: 'EPSG:3857'
});

var pointZoom = 16;

var map = new ol.Map({
    controls: [
        new ol.control.ScaleLine({
            "minWidth": 100,
            "units": "metric"
        }),
        new ol.control.LayerSwitcher({
            "showZoomTo": false,
            "allowFiltering": true,
            "allowReordering": true,
            "showDownload": true,
            "showOpacity": false,
            "tipLabel": "Layers"
        }),
        new ol.control.TimeLine({
            minDate: 1393628400000,
            maxDate: 1574550000000,
            interval: 10,
            numIntervals: 1000
        }),
        new ol.control.ZoomSlider(),
        new ol.control.Zoom({
            "zoomInTipLabel": "Zoom in",
            "zoomOutLabel": "-",
            "zoomOutTipLabel": "Zoom out",
            "duration": 250,
            "zoomInLabel": "+",
            "delta": 1.2
        })
    ],
    target: document.getElementById('map'),
    renderer: 'canvas',
    overlays: [overlayPopup],
    layers: layersList,
    view: view
});

var originalExtent = [377292.035100, 718249.455779, 379781.764269, 719551.205780];
map.getView().fit(originalExtent, map.getSize());

var currentInteraction;



popupLayers = [`<b>Area</b>: [Area]<br><b>rd_id</b>: [rd_id]<br><b>bd_type</b>: [bd_type]<br><b>bd_use</b>: [bd_use]<br><b>Approval</b>: [Approval]<br><b>sos_coord</b>: [sos_coord]`, ``, ``, ``, `<b>hosp_id</b>: [hosp_id]<br><b>hosp_name</b>: [hosp_name]<br><b>address</b>: [address]<br><b>category</b>: [category]<br><b>ownership</b>: [ownership]`, `<b>fire_id</b>: [fire_id]<br><b>fire_name</b>: [fire_name]<br><b>start_date</b>: [start_date]<br><b>end_date</b>: [end_date]<br><b>to_date</b>: [to_date]<br><b>fire_cause</b>: [fire_cause]<br><b>details</b>: [details]<br><b>dispatch</b>: [dispatch]<br><b>Lon</b>: [Lon]<br><b>Lat</b>: [Lat]<br><b>plan_link</b>: [plan_link]`];

var popupEventTriggered = function(evt) {
    var pixel = map.getEventPixel(evt.originalEvent);
    var coord = evt.coordinate;
    var popupTexts = [];
    var currentFeature;
    var allLayers = getAllNonBaseLayers();
    map.forEachFeatureAtPixel(pixel, function(feature, layer) {
        feature = decluster(feature);
        if (feature) {
            popupDef = popupLayers[allLayers.indexOf(layer)];
            if (popupDef) {
                var featureKeys = feature.getKeys();
                for (var i = 0; i < featureKeys.length; i++) {
                    if (featureKeys[i] != 'geometry') {
                        var value = feature.get(featureKeys[i]);
                        if (value) {
                            popupDef = popupDef.split("[" + featureKeys[i] + "]").join(
                                String(feature.get(featureKeys[i])))
                        } else {
                            popupDef = popupDef.split("[" + featureKeys[i] + "]").join("NULL")
                        }
                    }
                }
                popupTexts.push(popupDef);
            }
        }
    });

    var geojsonFormat = new ol.format.GeoJSON();
    var len = allLayers.length;
    for (var i = 0; i < len; i++) {
        var layer = allLayers[i];
        if (layer.getSource() instanceof ol.source.TileWMS) {
            var popupDef = popupLayers[allLayers.indexOf(layer)];
            if (popupDef == "#AllAttributes") {
                var url = layer.getSource().getGetFeatureInfoUrl(
                    evt.coordinate,
                    map.getView().getResolution(),
                    map.getView().getProjection(), {
                        'INFO_FORMAT': 'text/plain'
                    }
                );
                $.get(url, {}, function(data) {
                    popupTexts.push(data);
                });
            } else if (popupDef !== "") {
                var url = layer.getSource().getGetFeatureInfoUrl(
                    evt.coordinate,
                    map.getView().getResolution(),
                    map.getView().getProjection(), {
                        'INFO_FORMAT': 'application/json'
                    }
                );
                $.ajax({
                    url: url,
                    success: function(data) {
                        var features = geojsonFormat.readFeatures(data);
                        for (var f = 0; f < feature.length; f++) {
                            var feature = features[f];
                            var values = feature.getProperties();
                            for (var key in values) {
                                if (key != 'geometry') {
                                    var value = values[key];
                                    if (value) {
                                        popupDef = popupDef.split("[" + key + "]").join(
                                            String(value));
                                    } else {
                                        popupDef = popupDef.split("[" + key + "]").join("NULL");
                                    }
                                }
                            }
                            popupTexts.push(popupDef);
                        }
                    }
                });
            }
        }
    }
    if (popupTexts.length) {
        overlayPopup.setPosition(coord);
        content.innerHTML = popupTexts.join("<hr>");
        container.style.display = 'block';
    } else {
        container.style.display = 'none';
        closer.blur();
    }
};

map.on('singleclick', function(evt) {
    popupEventTriggered(evt);
});