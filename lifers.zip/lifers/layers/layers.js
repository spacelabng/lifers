baseLayers = [new ol.layer.Tile({
    type: 'base',
    title: 'ESRI world imagery',
    source: new ol.source.XYZ({
        attributions: [new ol.Attribution({
            html: ['Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community']
        })],
        url: 'http://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
    })
}), new ol.layer.Tile({
    type: 'base',
    title: 'ESRI world street map',
    source: new ol.source.XYZ({
        attributions: [new ol.Attribution({
            html: ['Tiles &copy; <a href="http://services.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer">ArcGIS</a>']
        })],
        url: 'http://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}'
    })
})];
var lyr_buildings = new ol.layer.Vector({
    opacity: 1.0,
    source: new ol.source.Vector({
        features: new ol.format.GeoJSON().readFeatures(geojson_buildings)
    }),

    style: style_buildings,
    title: "Buildings",
    filters: [],
    timeInfo: null,
    isSelectable: true
});
var lyr_roads = new ol.layer.Vector({
    opacity: 1.0,
    source: new ol.source.Vector({
        features: new ol.format.GeoJSON().readFeatures(geojson_roads)
    }),

    style: style_roads,
    title: "Roads",
    filters: [],
    timeInfo: null,
    isSelectable: true
});
var lyr_firestation = new ol.layer.Vector({
    opacity: 1.0,
    source: new ol.source.Vector({
        features: new ol.format.GeoJSON().readFeatures(geojson_firestation)
    }),

    style: style_firestation,
    title: "Fire Station",
    filters: [],
    timeInfo: null,
    isSelectable: true
});
var lyr_hydrant = new ol.layer.Vector({
    opacity: 1.0,
    source: new ol.source.Vector({
        features: new ol.format.GeoJSON().readFeatures(geojson_hydrant)
    }),

    style: style_hydrant,
    title: "Hydrant",
    filters: [],
    timeInfo: null,
    isSelectable: true
});
var lyr_hospitals = new ol.layer.Vector({
    opacity: 1.0,
    source: new ol.source.Vector({
        features: new ol.format.GeoJSON().readFeatures(geojson_hospitals)
    }),

    style: style_hospitals,
    title: "Hospitals",
    filters: [],
    timeInfo: null,
    isSelectable: true
});
var lyr_fires = new ol.layer.Vector({
    opacity: 1.0,
    source: new ol.source.Vector({
        features: new ol.format.GeoJSON().readFeatures(geojson_fires)
    }),

    style: style_fires,
    title: "Fires",
    filters: [],
    timeInfo: ["start_date", "to_date"],
    isSelectable: true
});

lyr_buildings.setVisible(false);
lyr_roads.setVisible(false);
lyr_firestation.setVisible(true);
lyr_hydrant.setVisible(true);
lyr_hospitals.setVisible(false);
lyr_fires.setVisible(true);
var layersList = [lyr_buildings, lyr_roads, lyr_firestation, lyr_hydrant, lyr_hospitals, lyr_fires];
Array.prototype.splice.apply(layersList, [0, 0].concat(baseLayers));