var textStyleCache_fires = {}
var clusterStyleCache_fires = {}
var selectedClusterStyleCache_fires = {}
var style_fires = function(feature, resolution) {

    if (feature.hide === true) {
        return null;
    }


    minFeatureTime = Date.parse(feature.get("start_date"))
    if (isNaN(minFeatureTime) || currentTimelineTime < minFeatureTime) {
        return null;
    }
    maxFeatureTime = Date.parse(feature.get("to_date"))
    if (isNaN(maxFeatureTime) || currentTimelineTime > maxFeatureTime) {
        return null;
    }



    var value = ""
    var style = [new ol.style.Style({
        image: new ol.style.Icon({
            scale: 0.035000,
            anchorOrigin: 'top-left',
            anchorXUnits: 'fraction',
            anchorYUnits: 'fraction',
            anchor: [0.5, 0.5],
            src: "styles/amenity=fire_station2550010.svg",
            rotation: 0.000000
        })
    })];
    var selectionStyle = [new ol.style.Style({
        image: new ol.style.Icon({
            scale: 0.035000,
            anchorOrigin: 'top-left',
            anchorXUnits: 'fraction',
            anchorYUnits: 'fraction',
            anchor: [0.5, 0.5],
            src: "styles/amenity=fire_station25520401.svg",
            rotation: 0.000000
        })
    })];
    var labelText = "";
    var key = value + "_" + labelText

    if (!textStyleCache_fires[key]) {
        var text = new ol.style.Text({
            font: '16.5px Calibri,sans-serif',
            text: labelText,
            fill: new ol.style.Fill({
                color: "rgba(0, 0, 0, 255)"
            }),
        });
        textStyleCache_fires[key] = new ol.style.Style({
            "text": text
        });
    }
    var allStyles = [textStyleCache_fires[key]];
    var selected = lyr_fires.selectedFeatures;
    if (selected && selected.indexOf(feature) != -1) {
        allStyles.push.apply(allStyles, selectionStyle);
    } else {
        allStyles.push.apply(allStyles, style);
    }
    return allStyles;
};