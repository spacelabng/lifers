var textStyleCache_hospitals = {}
var clusterStyleCache_hospitals = {}
var selectedClusterStyleCache_hospitals = {}
var style_hospitals = function(feature, resolution) {

    if (feature.hide === true) {
        return null;
    }


    var value = ""
    var style = [new ol.style.Style({
        image: new ol.style.Icon({
            scale: 0.035000,
            anchorOrigin: 'top-left',
            anchorXUnits: 'fraction',
            anchorYUnits: 'fraction',
            anchor: [0.5, 0.5],
            src: "styles/cross0025510.svg",
            rotation: 0.000000
        })
    })];
    var selectionStyle = [new ol.style.Style({
        image: new ol.style.Icon({
            scale: 0.035000,
            anchorOrigin: 'top-left',
            anchorXUnits: 'fraction',
            anchorYUnits: 'fraction',
            anchor: [0.5, 0.5],
            src: "styles/cross25520401.svg",
            rotation: 0.000000
        })
    })];
    var labelText = feature.get("hosp_name");
    var key = value + "_" + labelText

    if (!textStyleCache_hospitals[key]) {
        var text = new ol.style.Text({
            font: '18.0px Calibri,sans-serif',
            text: labelText,
            fill: new ol.style.Fill({
                color: "rgba(0, 0, 0, 255)"
            }),
        });
        textStyleCache_hospitals[key] = new ol.style.Style({
            "text": text
        });
    }
    var allStyles = [textStyleCache_hospitals[key]];
    var selected = lyr_hospitals.selectedFeatures;
    if (selected && selected.indexOf(feature) != -1) {
        allStyles.push.apply(allStyles, selectionStyle);
    } else {
        allStyles.push.apply(allStyles, style);
    }
    return allStyles;
};