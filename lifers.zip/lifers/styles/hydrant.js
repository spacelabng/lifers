var textStyleCache_hydrant = {}
var clusterStyleCache_hydrant = {}
var selectedClusterStyleCache_hydrant = {}
var style_hydrant = function(feature, resolution) {

    if (feature.hide === true) {
        return null;
    }


    var value = ""
    var style = [new ol.style.Style({
        image: new ol.style.Icon({
            scale: 0.040000,
            anchorOrigin: 'top-left',
            anchorXUnits: 'fraction',
            anchorYUnits: 'fraction',
            anchor: [0.5, 0.5],
            src: "styles/amenity_firestation300010.svg",
            rotation: 0.000000
        })
    })];
    var selectionStyle = [new ol.style.Style({
        image: new ol.style.Icon({
            scale: 0.040000,
            anchorOrigin: 'top-left',
            anchorXUnits: 'fraction',
            anchorYUnits: 'fraction',
            anchor: [0.5, 0.5],
            src: "styles/amenity_firestation325520401.svg",
            rotation: 0.000000
        })
    })];
    var labelText = "";
    var key = value + "_" + labelText

    if (!textStyleCache_hydrant[key]) {
        var text = new ol.style.Text({
            font: '16.5px Calibri,sans-serif',
            text: labelText,
            fill: new ol.style.Fill({
                color: "rgba(0, 0, 0, 255)"
            }),
        });
        textStyleCache_hydrant[key] = new ol.style.Style({
            "text": text
        });
    }
    var allStyles = [textStyleCache_hydrant[key]];
    var selected = lyr_hydrant.selectedFeatures;
    if (selected && selected.indexOf(feature) != -1) {
        allStyles.push.apply(allStyles, selectionStyle);
    } else {
        allStyles.push.apply(allStyles, style);
    }
    return allStyles;
};