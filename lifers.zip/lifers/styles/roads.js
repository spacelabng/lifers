var categories_roads = {
    "Express Way": [new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: "rgba(76,38,0,1.0)",
            lineDash: null,
            width: 7
        })
    }), new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: "rgba(76,38,0,1.0)",
            lineDash: null,
            width: 7
        })
    })],
    "Major Road": [new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: "rgba(108,58,83,1.0)",
            lineDash: null,
            width: 3
        })
    }), new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: "rgba(108,58,83,1.0)",
            lineDash: null,
            width: 3
        })
    })],
    "Street": [new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: "rgba(80,80,80,1.0)",
            lineDash: null,
            width: 0
        })
    })]
};
var categoriesSelected_roads = {
    "Express Way": [new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: "rgba(255, 204, 0, 1)",
            lineDash: null,
            width: 7
        })
    }), new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: "rgba(255, 204, 0, 1)",
            lineDash: null,
            width: 7
        })
    })],
    "Major Road": [new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: "rgba(255, 204, 0, 1)",
            lineDash: null,
            width: 3
        })
    }), new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: "rgba(255, 204, 0, 1)",
            lineDash: null,
            width: 3
        })
    })],
    "Street": [new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: "rgba(255, 204, 0, 1)",
            lineDash: null,
            width: 0
        })
    })]
};
var textStyleCache_roads = {}
var clusterStyleCache_roads = {}
var selectedClusterStyleCache_roads = {}
var style_roads = function(feature, resolution) {

    if (feature.hide === true) {
        return null;
    }


    var value = feature.get("rd_type");
    var style = categories_roads[value];
    var selectionStyle = categoriesSelected_roads[value];
    var labelText = feature.get("name");
    var key = value + "_" + labelText

    if (!textStyleCache_roads[key]) {
        var text = new ol.style.Text({
            font: '16.5px Calibri,sans-serif',
            text: labelText,
            fill: new ol.style.Fill({
                color: "rgba(0, 0, 0, 255)"
            }),
        });
        textStyleCache_roads[key] = new ol.style.Style({
            "text": text
        });
    }
    var allStyles = [textStyleCache_roads[key]];
    var selected = lyr_roads.selectedFeatures;
    if (selected && selected.indexOf(feature) != -1) {
        allStyles.push.apply(allStyles, selectionStyle);
    } else {
        allStyles.push.apply(allStyles, style);
    }
    return allStyles;
};